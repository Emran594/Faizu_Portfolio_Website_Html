/*!
 * Item: faizu
 * Description: Personal Portfolio Website
 * Author/Developer: Emran Sikder
 * Version: v1.1.0
 */
!function(n){"use strict";n((function(){})),n(window).on("load",(function(){}))}

(jQuery);